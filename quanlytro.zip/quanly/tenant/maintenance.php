<?php
session_start();
require '../config.php';

// Yêu cầu đăng nhập
if(!isset($_SESSION['tenant_id'])){
    header('Location: tenant-login.php');
    exit;
}

$tenant_id = (int)$_SESSION['tenant_id'];
$pageTitle = 'Yêu cầu bảo trì';
require 'header.php';

// Lấy phòng mà người thuê đang thuê (hợp đồng active)
$roomsStmt = $pdo->prepare("
    SELECT r.id, r.code, r.name 
    FROM rooms r
    JOIN contracts c ON r.id = c.room_id
    WHERE c.tenant_id = ? AND c.status = 'active'
");
$roomsStmt->execute([$tenant_id]);
$rooms = $roomsStmt->fetchAll();

$errors = [];

// Xử lý gửi yêu cầu
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])){
    $room_id = (int)$_POST['room_id'];
    $title   = trim($_POST['title']);
    $desc    = trim($_POST['description']);
    $imageName = null;

    // Kiểm tra tiêu đề
    if($title === '') $errors[] = 'Vui lòng nhập tiêu đề yêu cầu.';

    // Kiểm tra upload ảnh (nếu có)
    if(isset($_FILES['image']) && $_FILES['image']['error'] === 0){
        $allowed = ['image/png','image/jpeg','image/webp'];
        if(!in_array($_FILES['image']['type'], $allowed)){
            $errors[] = 'Chỉ chấp nhận file PNG, JPG hoặc WEBP.';
        } else {
            // Folder uploads ở root
            $uploadDir = __DIR__ . '/../assets/uploads/';
            if(!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $imageName = 'm_'.time().'_'.bin2hex(random_bytes(6)).'.'.$ext;

            $targetPath = $uploadDir . $imageName;
            move_uploaded_file($_FILES['image']['tmp_name'], $targetPath);
        }
    }

    // Nếu không có lỗi → lưu DB
    if(empty($errors)){
        $stmt = $pdo->prepare("
            INSERT INTO maintenance (room_id, tenant_id, title, description, image, status) 
            VALUES (?,?,?,?,?,?)
        ");
        $stmt->execute([$room_id, $tenant_id, $title, $desc, $imageName, 'pending']);

        header('Location: maintenance.php');
        exit;
    }
}

// Lấy danh sách yêu cầu của người thuê
$ticketsStmt = $pdo->prepare("
    SELECT m.*, r.code AS room_code 
    FROM maintenance m
    JOIN rooms r ON m.room_id = r.id
    WHERE m.tenant_id = ?
    ORDER BY m.id DESC
");
$ticketsStmt->execute([$tenant_id]);
$tickets = $ticketsStmt->fetchAll();
?>

<div class="card card-custom">
  <div class="card-body">

    <h3 class="mb-3">Gửi yêu cầu bảo trì</h3>

    <?php if($errors): ?>
      <div class="alert alert-danger">
        <?= implode('<br>', $errors) ?>
      </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="mb-4">
      <input type="hidden" name="create" value="1">

      <div class="row">
        <div class="col-md-4 mb-3">
          <label class="form-label">Phòng</label>
          <select name="room_id" class="form-control" required>
            <?php foreach($rooms as $r): ?>
              <option value="<?=$r['id']?>"><?=htmlspecialchars($r['code'].' - '.$r['name'])?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-8 mb-3">
          <label class="form-label">Tiêu đề</label>
          <input name="title" class="form-control" required>
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Mô tả chi tiết</label>
        <textarea name="description" class="form-control" rows="3"></textarea>
      </div>

      <div class="mb-3">
        <label class="form-label">Ảnh đính kèm (tùy chọn)</label>
        <input type="file" name="image" class="form-control">
      </div>

      <button class="btn btn-primary">Gửi yêu cầu</button>
    </form>

    <h4>Danh sách yêu cầu đã gửi</h4>

    <table class="table table-striped align-middle">
      <thead>
        <tr>
          <th>#</th>
          <th>Phòng</th>
          <th>Tiêu đề</th>
          <th>Trạng thái</th>
          <th>Ảnh</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($tickets as $t): ?>
        <tr>
          <td><?= $t['id'] ?></td>
          <td><?= htmlspecialchars($t['room_code']) ?></td>
          <td><?= htmlspecialchars($t['title']) ?></td>
          <td>
            <?php
              if($t['status'] === 'pending') echo '<span class="badge bg-warning text-dark">Đang chờ</span>';
              else if($t['status'] === 'processing') echo '<span class="badge bg-info text-dark">Đang xử lý</span>';
              else echo '<span class="badge bg-success">Hoàn thành</span>';
            ?>
          </td>

          <td>
            <?php if(!empty($t['image'])): ?>
              <a href="../assets/uploads/<?= $t['image'] ?>" target="_blank">Xem ảnh</a>
            <?php else: ?>
              —
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

  </div>
</div>

<?php require 'footer.php'; ?>
