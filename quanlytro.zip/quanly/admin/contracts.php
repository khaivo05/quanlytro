<?php
// Bắt đầu session nếu chưa có
if(session_status() === PHP_SESSION_NONE) session_start();

// Kiểm tra admin đã đăng nhập
if(!isset($_SESSION['admin_logged_in'])){
    header('Location: login.php');
    exit;
}

// Include config và header
require '../config.php';
$pageTitle = "Quản lý Hợp đồng";
require 'header.php';

// ======= Xử lý thêm hợp đồng =======
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])){
    $tenant_id = (int)$_POST['tenant_id'];
    $room_id   = (int)$_POST['room_id'];
    $rent      = (float)$_POST['rent'];
    $start     = $_POST['start_date'];
    $end       = $_POST['end_date'];

    // Thêm hợp đồng vào DB
    $stmt = $pdo->prepare("
        INSERT INTO contracts (tenant_id, room_id, rent, start_date, end_date, status) 
        VALUES (?,?,?,?,?,?)
    ");
    $stmt->execute([$tenant_id, $room_id, $rent, $start, $end, 'active']);

    // Cập nhật trạng thái phòng thành 'occupied'
    $pdo->prepare("UPDATE rooms SET status='occupied' WHERE id=?")->execute([$room_id]);

    // Quay về trang contracts
    header('Location: contracts.php');
    exit;
}

// ======= Lấy danh sách hợp đồng =======
$contracts = $pdo->query("
    SELECT c.*, t.fullname, r.name AS room_name 
    FROM contracts c
    JOIN tenants t ON c.tenant_id = t.id
    JOIN rooms r ON c.room_id = r.id
    ORDER BY c.id DESC
")->fetchAll();

// ======= Lấy danh sách tenants và rooms trống =======
$tenants = $pdo->query("SELECT * FROM tenants")->fetchAll();
$rooms   = $pdo->query("SELECT * FROM rooms WHERE status='available'")->fetchAll();

?>

<h2 class="mb-4">📄 Quản lý Hợp đồng</h2>

<!-- Form tạo hợp đồng mới -->
<div class="card p-3 mb-4">
    <h5>Tạo hợp đồng mới</h5>
    <form method="post" class="row g-3">
        <input type="hidden" name="create" value="1">

        <div class="col-md-3">
            <label>Khách thuê</label>
            <select name="tenant_id" class="form-select" required>
                <option value="">Chọn khách thuê</option>
                <?php foreach($tenants as $t): ?>
                    <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['fullname']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3">
            <label>Phòng</label>
            <select name="room_id" class="form-select" required>
                <option value="">Chọn phòng</option>
                <?php foreach($rooms as $r): ?>
                    <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-2">
            <label>Giá thuê</label>
            <input type="number" name="rent" class="form-control" required>
        </div>

        <div class="col-md-2">
            <label>Ngày bắt đầu</label>
            <input type="date" name="start_date" class="form-control" required>
        </div>

        <div class="col-md-2">
            <label>Ngày kết thúc</label>
            <input type="date" name="end_date" class="form-control">
        </div>

        <div class="col-12">
            <button class="btn btn-primary">Tạo hợp đồng</button>
        </div>
    </form>
</div>

<!-- Bảng danh sách hợp đồng -->
<table class="table table-striped table-bordered">
    <thead class="table-primary">
        <tr>
            <th>#</th>
            <th>Khách thuê</th>
            <th>Phòng</th>
            <th>Giá thuê</th>
            <th>Thời gian</th>
            <th>Trạng thái</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!$contracts): ?>
            <tr>
                <td colspan="6" class="text-center text-muted">Không có dữ liệu</td>
            </tr>
        <?php endif; ?>

        <?php foreach($contracts as $c): ?>
            <tr>
                <td><?= $c['id'] ?></td>
                <td><?= htmlspecialchars($c['fullname']) ?></td>
                <td><?= htmlspecialchars($c['room_name']) ?></td>
                <td><?= number_format($c['rent'],0,',','.') ?></td>
                <td><?= $c['start_date'] ?> → <?= $c['end_date'] ?: '---' ?></td>
                <td><?= htmlspecialchars($c['status']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require 'footer.php'; ?>
