<?php
session_start();
if(!isset($_SESSION['admin_user'])) header('Location: login.php');
require '../config.php';
require 'header.php';

// delete
if(isset($_GET['del_id'])){ $id=(int)$_GET['del_id']; $pdo->prepare("DELETE FROM rooms WHERE id=?")->execute([$id]); header('Location: rooms.php'); exit; }

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['addroom'])){
    $code=trim($_POST['code']); $name=trim($_POST['name']); $price=(float)$_POST['price']; $area=trim($_POST['area']); $status=$_POST['status']; $notes=trim($_POST['notes']);
    $pdo->prepare("INSERT INTO rooms (code,name,price,area,status,notes) VALUES (?,?,?,?,?,?)")->execute([$code,$name,$price,$area,$status,$notes]);
    header('Location: rooms.php'); exit;
}

$rooms = $pdo->query("SELECT * FROM rooms ORDER BY id DESC")->fetchAll();
?>
<h1>Quản lý phòng</h1>
<button class="btn btn-primary mb-3" data-bs-toggle="collapse" data-bs-target="#addRoom">Thêm phòng</button>
<div id="addRoom" class="collapse mb-3">
  <div class="card card-body">
    <form method="post"><input type="hidden" name="addroom" value="1">
      <div class="row">
        <div class="col-md-3"><input name="code" class="form-control" placeholder="Mã phòng" required></div>
        <div class="col-md-3"><input name="name" class="form-control" placeholder="Tên"></div>
        <div class="col-md-2"><input name="price" class="form-control" value="0"></div>
        <div class="col-md-2"><input name="area" class="form-control" placeholder="Diện tích"></div>
        <div class="col-md-2"><select name="status" class="form-control"><option value="available">available</option><option value="occupied">occupied</option><option value="maintenance">maintenance</option></select></div>
      </div>
      <div class="mt-2"><textarea name="notes" class="form-control" placeholder="Ghi chú"></textarea></div>
      <button class="btn btn-success mt-2">Lưu</button>
    </form>
  </div>
</div>

<table class="table">
  <thead><tr><th>#</th><th>Mã</th><th>Tên</th><th>Giá</th><th>Diện tích</th><th>Trạng thái</th><th>Hành động</th></tr></thead>
  <tbody>
    <?php foreach($rooms as $r): ?>
    <tr>
      <td><?=$r['id']?></td>
      <td><?=htmlspecialchars($r['code'])?></td>
      <td><?=htmlspecialchars($r['name'])?></td>
      <td><?=number_format($r['price'],0,',','.')?></td>
      <td><?=htmlspecialchars($r['area'])?></td>
      <td><?=htmlspecialchars($r['status'])?></td>
      <td>
        <a class="btn btn-sm btn-secondary" href="room_edit.php?id=<?=$r['id']?>">Sửa</a>
        <a class="btn btn-sm btn-danger" href="rooms.php?del_id=<?=$r['id']?>" onclick="return confirm('Xóa?')">Xóa</a>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php require 'footer.php'; ?>
