// placeholder
console.log('Assets loaded');
