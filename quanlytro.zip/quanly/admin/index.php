<?php
session_start();
if(!isset($_SESSION['admin_logged_in'])) header('Location: login.php');
require '../config.php';
$pageTitle = "Dashboard";
require 'header.php';

$totalRooms = $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$occupied = $pdo->query("SELECT COUNT(*) FROM rooms WHERE status='occupied'")->fetchColumn();
$totalTenants = $pdo->query("SELECT COUNT(*) FROM tenants")->fetchColumn();
$unpaid = $pdo->query("SELECT COUNT(*) FROM bills WHERE is_paid=0")->fetchColumn();
?>

<h1 class="mb-4">Dashboard</h1>
<div class="row g-3">
  <div class="col-md-3">
    <div class="card rooms text-center">
        <h6>Tổng phòng</h6>
        <h3><?=$totalRooms?></h3>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card occupied text-center">
        <h6>Đang thuê</h6>
        <h3><?=$occupied?></h3>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card tenants text-center">
        <h6>Khách thuê</h6>
        <h3><?=$totalTenants?></h3>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card unpaid text-center">
        <h6>Hóa đơn chưa trả</h6>
        <h3><?=$unpaid?></h3>
    </div>
  </div>
</div>

<?php require 'footer.php'; ?>
