<?php
session_start();
require '../config.php';
if(!isset($_SESSION['tenant_id'])) header('Location: login.php');
$tenant_id = (int)$_SESSION['tenant_id'];
require 'header.php';
$stmt = $pdo->prepare("SELECT c.*, r.* FROM contracts c JOIN rooms r ON c.room_id=r.id WHERE c.tenant_id=? AND c.status='active' LIMIT 1");
$stmt->execute([$tenant_id]); $data = $stmt->fetch();
?>
<div class="card card-custom">
  <div class="card-body">
    <h4>Thông tin phòng</h4>
    <?php if(!$data): ?><div class="alert alert-info">Không tìm thấy phòng/hợp đồng.</div><?php else: ?>
    <table class="table">
      <tr><th>Phòng</th><td><?=htmlspecialchars($data['code'].' - '.$data['name'])?></td></tr>
      <tr><th>Giá thuê</th><td><?=number_format($data['rent'],0,',','.')?> VNĐ</td></tr>
      <tr><th>Diện tích</th><td><?=htmlspecialchars($data['area'])?></td></tr>
      <tr><th>Tiền cọc</th><td><?=number_format($data['deposit'],0,',','.')?> VNĐ</td></tr>
      <tr><th>Ngày bắt đầu</th><td><?=htmlspecialchars($data['start_date'])?></td></tr>
      <tr><th>Ngày kết thúc</th><td><?=htmlspecialchars($data['end_date']?:'---')?></td></tr>
    </table>
    <?php endif; ?>
  </div>
</div>
<?php require 'footer.php'; ?>
