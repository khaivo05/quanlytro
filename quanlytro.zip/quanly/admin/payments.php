<?php
session_start();
if(!isset($_SESSION['admin_logged_in'])){
    header('Location: login.php');
    exit;
}

require '../config.php';
$pageTitle = "Lịch sử Thanh toán";
require 'header.php';

// Lấy danh sách thanh toán kèm thông tin hợp đồng, phòng, khách thuê
$payments = $pdo->query("
    SELECT p.*, b.period_month, r.code AS room_code, t.fullname
    FROM payments p
    JOIN bills b ON p.bill_id = b.id
    JOIN contracts c ON b.contract_id = c.id
    JOIN tenants t ON c.tenant_id = t.id
    JOIN rooms r ON c.room_id = r.id
    ORDER BY p.paid_at DESC
")->fetchAll();
?>

<h2 class="mb-4">💰 Lịch sử Thanh toán</h2>

<table class="table table-striped table-bordered">
    <thead class="table-primary">
        <tr>
            <th>#</th>
            <th>Phòng</th>
            <th>Khách thuê</th>
            <th>Kỳ</th>
            <th>Số tiền</th>
            <th>Ngày thanh toán</th>
            <th>Phương thức</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!$payments): ?>
            <tr>
                <td colspan="7" class="text-center text-muted">Không có dữ liệu</td>
            </tr>
        <?php endif; ?>

        <?php foreach($payments as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['room_code']) ?></td>
            <td><?= htmlspecialchars($p['fullname']) ?></td>
            <td><?= htmlspecialchars($p['period_month']) ?></td>
            <td><?= number_format($p['amount'],0,',','.') ?></td>
            <td><?= $p['paid_at'] ?></td>
            <td><?= htmlspecialchars($p['method']) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require 'footer.php'; ?>
