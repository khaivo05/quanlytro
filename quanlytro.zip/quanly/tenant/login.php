<?php
session_start();
require '../config.php';
if(isset($_SESSION['tenant_id'])) header('Location: index.php');

$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $phone = trim($_POST['phone']);
    $id_card = trim($_POST['id_card']);
    $stmt = $pdo->prepare("SELECT id, fullname FROM tenants WHERE phone=? AND id_card=? LIMIT 1");
    $stmt->execute([$phone,$id_card]);
    $t = $stmt->fetch();
    if($t){
        $_SESSION['tenant_id'] = $t['id'];
        $_SESSION['tenant_name'] = $t['fullname'];
        header('Location: index.php'); exit;
    } else $err = 'Thông tin không chính xác';
}
require 'header.php';
?>
<div class="card card-custom mx-auto" style="max-width:520px">
  <div class="card-body">
    <h4>Đăng nhập - Người thuê</h4>
    <?php if($err): ?><div class="alert alert-danger"><?=$err?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3"><label>Số điện thoại</label><input name="phone" class="form-control" required></div>
      <div class="mb-3"><label>CMND/CCCD</label><input name="id_card" class="form-control" required></div>
      <button class="btn btn-primary">Đăng nhập</button>
    </form>
  </div>
</div>
<?php require 'footer.php'; ?>
