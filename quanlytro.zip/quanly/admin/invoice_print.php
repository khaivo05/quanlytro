<?php
session_start(); if(!isset($_SESSION['admin_user'])) header('Location: login.php');
require '../config.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT b.*, c.rent, t.fullname, t.phone, t.address, r.code as room_code, r.name as room_name FROM bills b JOIN contracts c ON b.contract_id=c.id JOIN tenants t ON c.tenant_id=t.id JOIN rooms r ON c.room_id=r.id WHERE b.id=?");
$stmt->execute([$id]); $bill = $stmt->fetch();
if(!$bill){ echo "Not found"; exit; }
?>
<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>Hóa đơn #<?=$bill['id']?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head><body>
<div class="container my-4">
  <div class="card card-body">
    <h3>HÓA ĐƠN #<?=$bill['id']?></h3>
    <p>Phòng: <?=$bill['room_code']?> - <?=$bill['room_name']?></p>
    <p>Khách: <?=$bill['fullname']?> | <?=$bill['phone']?></p>
    <table class="table"><tr><th>Mục</th><th class="text-end">Số</th><th class="text-end">Đơn giá</th><th class="text-end">Tiền</th></tr>
    <tr><td>Điện</td><td class="text-end"><?=$bill['elec_usage']?></td><td class="text-end"><?=number_format($bill['elec_unit_price'],0,',','.')?></td><td class="text-end"><?=number_format($bill['elec_usage']*$bill['elec_unit_price'],0,',','.')?></td></tr>
    <tr><td>Nước</td><td class="text-end"><?=$bill['water_usage']?></td><td class="text-end"><?=number_format($bill['water_unit_price'],0,',','.')?></td><td class="text-end"><?=number_format($bill['water_usage']*$bill['water_unit_price'],0,',','.')?></td></tr>
    <tr><td>Khác</td><td></td><td></td><td class="text-end"><?=number_format($bill['other_charges'],0,',','.')?></td></tr>
    <tr><th colspan="3">Tổng</th><th class="text-end"><?=number_format($bill['total_amount'],0,',','.')?></th></tr></table>
    <div class="mt-3"><button class="btn btn-primary" onclick="window.print()">In</button></div>
  </div>
</div>
</body></html>
