<?php
session_start();
if(!isset($_SESSION['admin_logged_in'])){
    header('Location: login.php');
    exit;
}

require '../config.php';
$pageTitle = "Quản lý Hóa đơn";
require 'header.php';

// Lấy tháng/năm từ GET hoặc mặc định hiện tại
$month = $_GET['month'] ?? date('m');
$year  = $_GET['year'] ?? date('Y');

// ===== TẠO HÓA ĐƠN MỚI =====
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])){
    $contract_id      = (int)$_POST['contract_id'];
    $period_month     = $_POST['period_month'];
    $elec_usage       = (float)$_POST['elec_usage'];
    $water_usage      = (float)$_POST['water_usage'];
    $elec_unit_price  = (float)$_POST['elec_unit_price'];
    $water_unit_price = (float)$_POST['water_unit_price'];
    $other_charges    = (float)$_POST['other_charges'];

    // Lấy tiền phòng từ hợp đồng
    $stmt_rent = $pdo->prepare("SELECT rent FROM contracts WHERE id = ?");
    $stmt_rent->execute([$contract_id]);
    $room_rent = (float)$stmt_rent->fetchColumn();

    // Tính tổng = tiền phòng + điện + nước + phí khác
    $total_amount = $room_rent + ($elec_usage*$elec_unit_price) + ($water_usage*$water_unit_price) + $other_charges;

    // Thêm hóa đơn
    $stmt = $pdo->prepare("
        INSERT INTO bills (contract_id, period_month, elec_usage, water_usage, elec_unit_price, water_unit_price, other_charges, total_amount, is_paid, bill_date)
        VALUES (?,?,?,?,?,?,?,?,0,CURDATE())
    ");
    $stmt->execute([$contract_id,$period_month,$elec_usage,$water_usage,$elec_unit_price,$water_unit_price,$other_charges,$total_amount]);

    header('Location: bills.php?month='.$month.'&year='.$year);
    exit;
}

// ===== LẤY DANH SÁCH HÓA ĐƠN =====
$stmt = $pdo->prepare("
    SELECT b.*, c.rent AS room_rent, t.fullname, r.name AS room_name,
           (b.elec_usage * b.elec_unit_price) AS elec_amount,
           (b.water_usage * b.water_unit_price) AS water_amount
    FROM bills b
    JOIN contracts c ON b.contract_id = c.id
    JOIN tenants t ON c.tenant_id = t.id
    JOIN rooms r ON c.room_id = r.id
    WHERE MONTH(b.bill_date)=? AND YEAR(b.bill_date)=?
    ORDER BY b.id DESC
");
$stmt->execute([$month, $year]);
$bills = $stmt->fetchAll();

// ===== LẤY DANH SÁCH HỢP ĐỒNG để tạo hóa đơn =====
$contracts = $pdo->query("
    SELECT c.id, t.fullname, r.name AS room_name, c.rent
    FROM contracts c
    JOIN tenants t ON c.tenant_id = t.id
    JOIN rooms r ON c.room_id = r.id
    ORDER BY c.id DESC
")->fetchAll();
?>

<h2 class="mb-4">📄 Quản lý Hóa đơn</h2>

<!-- Form lọc tháng/năm -->
<form method="get" class="row g-3 mb-4">
    <div class="col-md-3">
        <label class="form-label">Tháng</label>
        <select name="month" class="form-select">
            <?php for($m=1;$m<=12;$m++): ?>
            <option value="<?=$m?>" <?=($m==$month?'selected':'')?>><?=$m?></option>
            <?php endfor; ?>
        </select>
    </div>
    <div class="col-md-3">
        <label class="form-label">Năm</label>
        <select name="year" class="form-select">
            <?php for($y=2023;$y<=2030;$y++): ?>
            <option value="<?=$y?>" <?=($y==$year?'selected':'')?>><?=$y?></option>
            <?php endfor; ?>
        </select>
    </div>
    <div class="col-md-3 d-flex align-items-end">
        <button class="btn btn-primary w-100">Lọc</button>
    </div>
</form>

<!-- Form tạo hóa đơn -->
<div class="card p-3 mb-4">
    <h5>Tạo hóa đơn mới</h5>
    <form method="post" class="row g-3">
        <input type="hidden" name="create" value="1">

        <div class="col-md-3">
            <label>Hợp đồng</label>
            <select name="contract_id" class="form-select" required>
                <option value="">Chọn hợp đồng</option>
                <?php foreach($contracts as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['room_name'].' - '.$c['fullname']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-2">
            <label>Kỳ</label>
            <input type="month" name="period_month" class="form-control" required>
        </div>

        <div class="col-md-2">
            <label>Tiền điện (kWh)</label>
            <input type="number" step="0.01" name="elec_usage" class="form-control" required>
        </div>

        <div class="col-md-2">
            <label>Tiền nước (m³)</label>
            <input type="number" step="0.01" name="water_usage" class="form-control" required>
        </div>

        <div class="col-md-1">
            <label>Giá điện</label>
            <input type="number" step="0.01" name="elec_unit_price" class="form-control" value="3500" required>
        </div>

        <div class="col-md-1">
            <label>Giá nước</label>
            <input type="number" step="0.01" name="water_unit_price" class="form-control" value="8000" required>
        </div>

        <div class="col-md-1">
            <label>Phí Khác</label>
            <input type="number" step="0.01" name="other_charges" class="form-control" value="0">
        </div>

        <div class="col-12">
            <button class="btn btn-success">Tạo hóa đơn</button>
        </div>
    </form>
</div>

<!-- Bảng hóa đơn -->
<table class="table table-striped table-bordered">
    <thead class="table-primary">
        <tr>
            <th>#</th>
            <th>Phòng</th>
            <th>Khách thuê</th>
            <th>Kỳ</th>
            <th>Tiền phòng</th>
            <th>Điện</th>
            <th>Nước</th>
            <th>Khác</th>
            <th>Tổng</th>
            <th>TT</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!$bills): ?>
        <tr>
            <td colspan="10" class="text-center text-muted">Không có dữ liệu</td>
        </tr>
        <?php endif; ?>

        <?php foreach($bills as $b): ?>
        <tr>
            <td><?= $b['id'] ?></td>
            <td><?= htmlspecialchars($b['room_name']) ?></td>
            <td><?= htmlspecialchars($b['fullname']) ?></td>
            <td><?= htmlspecialchars($b['period_month']) ?></td>
            <td><?= number_format($b['room_rent'],0,',','.') ?></td>
            <td><?= number_format($b['elec_amount'],0,',','.') ?></td>
            <td><?= number_format($b['water_amount'],0,',','.') ?></td>
            <td><?= number_format($b['other_charges'],0,',','.') ?></td>
            <td><?= number_format($b['total_amount'],0,',','.') ?></td>
            <td><?= $b['is_paid'] ? '<span class="badge bg-success">Đã trả</span>' : '<span class="badge bg-warning text-dark">Chưa trả</span>' ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require 'footer.php'; ?>