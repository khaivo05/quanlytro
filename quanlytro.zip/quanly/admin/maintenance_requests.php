<?php
session_start(); if(!isset($_SESSION['admin_user'])) header('Location: login.php');
require '../config.php'; require 'header.php';
if(isset($_GET['set']) && isset($_GET['id'])){
    $id=(int)$_GET['id']; $set=$_GET['set']; if(in_array($set,['new','in_progress','done'])) $pdo->prepare("UPDATE maintenance SET status=? WHERE id=?")->execute([$set,$id]);
    header('Location: maintenance_requests.php'); exit;
}
$tickets = $pdo->query("SELECT m.*, r.code as room_code, t.fullname FROM maintenance m JOIN rooms r ON m.room_id=r.id LEFT JOIN tenants t ON m.tenant_id=t.id ORDER BY m.id DESC")->fetchAll();
?>
<h1>Yêu cầu bảo trì</h1>
<table class="table">
<thead><tr><th>#</th><th>Phòng</th><th>Người</th><th>Tiêu đề</th><th>Trạng thái</th><th>Ảnh</th><th>Hành động</th></tr></thead>
<tbody>
<?php foreach($tickets as $t): ?>
<tr>
  <td><?=$t['id']?></td>
  <td><?=htmlspecialchars($t['room_code'])?></td>
  <td><?=htmlspecialchars($t['fullname'])?></td>
  <td><?=htmlspecialchars($t['title'])?></td>
  <td><?=htmlspecialchars($t['status'])?></td>
  <td><?php if($t['image']): ?><a href="../assets/uploads/<?=htmlspecialchars($t['image'])?>" target="_blank">Xem</a><?php else: ?>-<?php endif; ?></td>
  <td>
    <?php if($t['status']!='in_progress'): ?><a class="btn btn-sm btn-warning" href="maintenance_requests.php?id=<?=$t['id']?>&set=in_progress">Đang xử lý</a><?php endif; ?>
    <?php if($t['status']!='done'): ?><a class="btn btn-sm btn-success" href="maintenance_requests.php?id=<?=$t['id']?>&set=done">Hoàn thành</a><?php endif; ?>
  </td>
</tr>
<?php endforeach;?>
</tbody>
</table>
<?php require 'footer.php'; ?>
