<?php
session_start();
if(!isset($_SESSION['admin_user'])) header('Location: login.php');
require '../config.php'; require 'header.php';
if(isset($_GET['del_id'])){ $id=(int)$_GET['del_id']; $pdo->prepare("DELETE FROM tenants WHERE id=?")->execute([$id]); header('Location: tenants.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['addtenant'])){
    $fullname=trim($_POST['fullname']); $phone=trim($_POST['phone']); $email=trim($_POST['email']); $id_card=trim($_POST['id_card']); $address=trim($_POST['address']);
    $pdo->prepare("INSERT INTO tenants (fullname,phone,email,id_card,address) VALUES (?,?,?,?,?)")->execute([$fullname,$phone,$email,$id_card,$address]);
    header('Location: tenants.php'); exit;
}
$tenants = $pdo->query("SELECT * FROM tenants ORDER BY id DESC")->fetchAll();
?>
<h1>Khách thuê</h1>
<button class="btn btn-primary mb-3" data-bs-toggle="collapse" data-bs-target="#addTenant">Thêm khách</button>
<div id="addTenant" class="collapse mb-3">
  <div class="card card-body">
    <form method="post"><input type="hidden" name="addtenant" value="1">
      <div class="row"><div class="col-md-6"><input name="fullname" class="form-control" placeholder="Họ tên" required></div><div class="col-md-6"><input name="phone" class="form-control" placeholder="Phone"></div></div>
      <div class="row mt-2"><div class="col-md-6"><input name="email" class="form-control" placeholder="Email"></div><div class="col-md-6"><input name="id_card" class="form-control" placeholder="CMND/CCCD"></div></div>
      <div class="mt-2"><textarea name="address" class="form-control" placeholder="Địa chỉ"></textarea></div>
      <button class="btn btn-success mt-2">Lưu</button>
    </form>
  </div>
</div>
<table class="table">
<thead><tr><th>#</th><th>Họ tên</th><th>Phone</th><th>Email</th><th>CMND</th><th>Hành động</th></tr></thead>
<tbody>
<?php foreach($tenants as $t): ?>
<tr>
  <td><?=$t['id']?></td>
  <td><?=htmlspecialchars($t['fullname'])?></td>
  <td><?=htmlspecialchars($t['phone'])?></td>
  <td><?=htmlspecialchars($t['email'])?></td>
  <td><?=htmlspecialchars($t['id_card'])?></td>
  <td>
    <a class="btn btn-sm btn-secondary" href="tenant_edit.php?id=<?=$t['id']?>">Sửa</a>
    <a class="btn btn-sm btn-danger" href="tenants.php?del_id=<?=$t['id']?>" onclick="return confirm('Xóa?')">Xóa</a>
  </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php require 'footer.php'; ?>
