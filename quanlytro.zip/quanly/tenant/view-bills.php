<?php
session_start();
require '../config.php';
if(!isset($_SESSION['tenant_id'])) header('Location: login.php');
$tenant_id = (int)$_SESSION['tenant_id'];
require 'header.php';

// Lấy danh sách hóa đơn của tenant
$stmt = $pdo->prepare("
    SELECT b.*, r.code AS room_code 
    FROM bills b 
    JOIN contracts c ON b.contract_id=c.id 
    JOIN rooms r ON c.room_id=r.id 
    WHERE c.tenant_id=? 
    ORDER BY b.id DESC
");
$stmt->execute([$tenant_id]);
$bills = $stmt->fetchAll();
?>

<div class="card card-custom">
  <div class="card-body">
    <h4>Hóa đơn của bạn</h4>
    <?php if(!$bills): ?>
      <div class="alert alert-info">Chưa có hóa đơn.</div>
    <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>Kỳ</th>
          <th>Phòng</th>
          <th>Tổng</th>
          <th>Trạng thái</th>
          <th>Hành động</th>
          <th>Thanh toán</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($bills as $b): ?>
        <tr>
          <td><?=$b['id']?></td>
          <td><?=htmlspecialchars($b['period_month'])?></td>
          <td><?=htmlspecialchars($b['room_code'])?></td>
          <td><?=number_format($b['total_amount'],0,',','.')?></td>
          <td><?= $b['is_paid'] ? '<span class="badge bg-success">Đã trả</span>' : '<span class="badge bg-warning text-dark">Chưa</span>' ?></td>
          <td>
            <a class="btn btn-sm btn-info" href="../admin/invoice_print.php?id=<?=$b['id']?>" target="_blank">Xem/In</a>
          </td>
          <td>
            <?php if(!$b['is_paid']): ?>
              <form method="post" action="pay.php" style="display:inline;">
                <input type="hidden" name="bill_id" value="<?=$b['id']?>">
                <button class="btn btn-sm btn-success">Thanh toán</button>
              </form>
            <?php else: ?>
              <span class="text-muted">-</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<?php require 'footer.php'; ?>
