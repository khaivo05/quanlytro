<?php
session_start();
require '../config.php';

if(!isset($_SESSION['tenant_id'])){
    header('Location: login.php');
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bill_id'])){
    $bill_id = (int)$_POST['bill_id'];

    // Lấy tổng hóa đơn
    $stmt = $pdo->prepare("SELECT total_amount FROM bills WHERE id=? AND is_paid=0");
    $stmt->execute([$bill_id]);
    $total = $stmt->fetchColumn();

    if($total !== false){
        // Cập nhật hóa đơn là đã thanh toán
        $pdo->prepare("UPDATE bills SET is_paid=1 WHERE id=?")->execute([$bill_id]);

        // Thêm vào bảng payments (nếu có)
        $pdo->prepare("INSERT INTO payments (bill_id, amount, paid_at, method) VALUES (?,?,NOW(),'Online')")
            ->execute([$bill_id, $total]);
    }

    header('Location: view-bills.php');
    exit;
}
