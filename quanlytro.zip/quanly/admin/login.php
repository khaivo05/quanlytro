<?php
session_start();
require '../config.php';

if(isset($_SESSION['admin_logged_in'])) header('Location: index.php');

$err = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $u = trim($_POST['username']);
    $p = trim($_POST['password']);

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username=? LIMIT 1");
    $stmt->execute([$u]);
    $a = $stmt->fetch();

    if($a && $a['password'] === $p){
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $a['username'];
        $_SESSION['admin_name'] = $a['fullname'];
        header('Location: index.php'); exit;
    } else $err = 'Sai username hoặc password';
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<title>Admin Login</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-5 mt-5">
      <div class="card">
        <div class="card-body">
          <h4 class="mb-3">Đăng nhập (Admin)</h4>
          <?php if($err): ?><div class="alert alert-danger"><?=$err?></div><?php endif; ?>
          <form method="post">
            <div class="mb-3"><label>Username</label><input name="username" class="form-control" required></div>
            <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
            <button class="btn btn-primary w-100">Đăng nhập</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
