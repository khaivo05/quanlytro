<?php
if(session_status() === PHP_SESSION_NONE) session_start();
?>
<!doctype html>
<html lang="vi">
<head>
  <link rel="stylesheet" href="../assets/css/background.css">
  <meta charset="utf-8">
  <title>Admin - Quản lý phòng trọ</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="../assets/img/logo.png" height="40" class="me-2">
      <strong>Trọ Pluss - ADmin</strong>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navAdmin">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="rooms.php">Phòng</a></li>
        <li class="nav-item"><a class="nav-link" href="tenants.php">Khách thuê</a></li>
        <li class="nav-item"><a class="nav-link" href="contracts.php">Hợp đồng</a></li>
        <li class="nav-item"><a class="nav-link" href="bills.php">Hóa đơn</a></li>
        <li class="nav-item"><a class="nav-link" href="payments.php">Thanh toán</a></li>
        <li class="nav-item"><a class="nav-link" href="maintenance_requests.php">Yêu cầu bảo trì</a></li>
        <li class="nav-item"><a class="nav-link" href="../tenant/login.php" target="_blank">Portal Người thuê</a></li>
        <?php if(isset($_SESSION['admin_user'])): ?>
          <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Đăng xuất</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4 page-content">

